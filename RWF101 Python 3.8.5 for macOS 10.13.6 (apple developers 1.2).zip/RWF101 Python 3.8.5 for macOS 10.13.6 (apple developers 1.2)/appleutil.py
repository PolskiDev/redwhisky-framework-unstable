import os
#LUA and Python Script Unified Language

#Show a text-mode Calar
def showCalar():
	return os.system('cal')

#Show current date and time
def date():
	return os.system('date')

#Show a history of users log in
def showUsersLogin():
	return os.system('last')

#Show free space available on Hard Disk
def showFreeSpace():
	return os.system('df')

#Change the password of the current user on macOS
def changeUserPassword():
	print("===============================================================================")
	print("You are going to change the default password of the current local user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("===============================================================================")

	return os.system('passwd')

### ROOT USER SECTION ###
#Enable default user as root
def enableRootUser():
	print("======================================================================")
	print("You are going to enable the root user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("======================================================================")

	return os.system('dsenableroot')

#Disable default user as root
def disableRootUser():
	return os.system('dsenableroot -d')


#Enable defined user as root
def enableDefinedRootUser(user):
	print("======================================================================")
	print("You are going to enable <"+user+"> as root user")
	print("If you do not agree with it, you should stop this")
	print("program right now!")
	print("======================================================================")

	return os.system('dsenableroot -u '+user)

#Disable defined user as root
def disableDefinedRootUser(user):
	return os.system('dsenableroot -d -u '+user)

#Clear RAM memory
def ClearMemory():
	return os.system('sudo purge')

#Restart Finder
def RestartFinder():
	return os.system('killall Finder')

#Repeat an AudioMessage
def AudioMessage(msg):
	return os.system('say '+msg)

#Clear terminal screen
def ClearTerminal():
	return os.system('clear')

#Show history of all recent typed commands
#on Apple MacOS
def CmdHistory():
	return os.system('history')

#Show current work directory
def CurrentDir():
	return os.system('pwd')

def cwd():
	return os.system('pwd')


#Counting lines in archive
def CountLines(archive):
	return os.system('wc -l '+archive)

#Counting words in archive
def CountWords(archive):
	return os.system('wc -w '+archive)

#Counting characters in archive
def CountChar(archive):
	return os.system('wc '+archive)

#Counting characters in archive
def CountCharacters(archive):
	return os.system('wc '+archive)


#See the content inside a text archive
def ShowSource(archive, ftype):
	if ftype == None or 0:
		return os.system('cat '+archive)

	elif ftype == "lines" or 1:
		return os.system('cat -n '+archive)
	else:
		print("Invalid code! Use 0 to simple opening or 1 to enumerate each line of the archive")
	


#CODES OF OPENING:
	#CODE [nil, 0] - Only cat
	#CODE ["lines", 1] - Cat with line numbers

#USES OF ShowSource:
	#ShowSource("teste.txt", 0)
	#ShowSource("teste.txt", 1)



#Rebooting Options
def reboot():
	return os.system('sudo reboot')


#Power off Options
def shutdown():
	return os.system('sudo shutdown -h now')

#Power Off at specific time
def specificMinuteShutdown(minuteTime):
	return os.system('sudo shutdown -h +'+minuteTime)

def specificShutdown(hourTime,minuteTime):
	return os.system('sudo shutdown -h ' +hourTime +':' +minuteTime)

#Open external application, archive or website on the Internet
def openApplication(appName):
	return os.system('open -a '+appName)

def openArchive(archName):
	return os.system('open '+archName)

#Examples of use:
	#openApplication("Safari")
	#openArchive("myfile.txt")
	
	#SPECIFIC SHUTDOWN:
	#specificShutdown(10,30)
