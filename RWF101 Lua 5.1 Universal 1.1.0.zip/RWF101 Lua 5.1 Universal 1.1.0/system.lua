require('os')
local system = {}

--Commands of the operating system
function system.runtime(com)
	return os.execute(com) --Executing external programmes and isolated commands
end
function system.stopTask(program)
	--Be careful when you use this instruction
	--You can make *irrecoverable* things such as
	--closing the Microsoft Windows Graphic Interface
	return os.exit(program)
end

--Deleting files
function system.delete(path, opsys)
	if opsys == "win" or 0 then
		return runtime('rmdir /S /Q '..path) --For MS Windows

	elseif opsys == "macos" or 1 then
		return print('Use system.appleremove() to access this feature')

	else
		return print('Invalid code on function delete!') --Invalid code error
	end
end

--Delete files or archives on Apple macOS
--This command DOES NOT delete MacOS System itself [system.appleremove]

--CODE 1 [remove]
--CODE 0 [directory]
function system.appleremove(ftype, path)
	if ftype == "file" or "archive" or 1 then
		return os.execute('rm '..path) --Remove files

	elseif ftype == "folder" or "directory" or "dir" or 0 then
		return os.execute('rmdir '..path) --Remove directories
	end
end

--Renaming files
function system.rename(old_path, new_path,opsys)
	if opsys == "win" or 0 then
		return os.execute('ren '..old_path..' '..new_path) --For MS Windows

	elseif opsys == "macos" or 1 then
		return os.execute('mv '..old_path..' '..new_path) --For Apple MacOS
	else
		return print('Invalid code on function rename!') --Invalid code error
	end
end

--Getting Operating System current date
function system.getDate()
	return os.date()
end
return system
--system.rename('/etc/texto.txt', "win")
--system.rename()
--system.delete()
--system.getDate()
