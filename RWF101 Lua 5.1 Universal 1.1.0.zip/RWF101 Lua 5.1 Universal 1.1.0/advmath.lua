local advmath = {}
require('math')

function advmath.sqroot(num)
	return math.sqrt(num)
end
function advmath.mathpi()
	return math.pi
end

--Advanced Math Functions
function advmath.absnum(num)
	return math.abs(num)
end

--factorial [PROBLEMA PARA SER CORRIGIDO]
function advmath.factorial(num)
	if num <= 0 then
		return 1
	else
		return num * factorial(num-1)
	end
end


function advmath.random(min,max)
	return math.random(min,max) --ERRO PARA SER CORRIGIDO AQUI
end
return advmath
