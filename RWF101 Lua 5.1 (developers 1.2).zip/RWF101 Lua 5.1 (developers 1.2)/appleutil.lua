local appleutil = {}
--LUA and Python Script Unified Language

--Show a text-mode Calendar
function appleutil.showCalendar()
	return os.execute('cal')
end
--Show current date and time
function appleutil.date( ... )
	return os.execute('date')
end
--Show a history of users log in
function appleutil.showUsersLogin()
	return os.execute('last')
end
--Show free space available on Hard Disk
function appleutil.showFreeSpace()
	return os.execute('df')
end
--Change the password of the current user on macOS
function appleutil.changeUserPassword()
	print("===============================================================================")
	print("You are going to change the default password of the current local user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("===============================================================================")

	return os.execute('passwd')
end

--[[
	ROOT USER SECTION
]]
--Enable default user as root
function appleutil.enableRootUser()
	print("======================================================================")
	print("You are going to enable the root user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("======================================================================")

	return os.execute('dsenableroot')
end
--Disable default user as root
function appleutil.disableRootUser( ... )
	return os.execute('dsenableroot -d')
end

--Enable defined user as root
function appleutil.enableDefinedRootUser(user)
	print("======================================================================")
	print("You are going to enable <"..user.."> as root user")
	print("If you do not agree with it, you should stop this")
	print("program right now!")
	print("======================================================================")

	return os.execute('dsenableroot -u '..user)
end
--Disable defined user as root
function appleutil.disableDefinedRootUser(user)
	return os.execute('dsenableroot -d -u '..user)
end
--Clear RAM memory
function appleutil.ClearMemory( ... )
	return os.execute('sudo purge')
end
--Restart Finder
function appleutil.RestartFinder( ... )
	return os.execute('killall Finder')
end
--Repeat an AudioMessage
function appleutil.AudioMessage(msg)
	return os.execute('say '..msg)
end
--Clear terminal screen
function appleutil.ClearTerminal( ... )
	return os.execute('clear')
end
--Show history of all recent typed commands
--on Apple MacOS
function appleutil.CmdHistory( ... )
	return os.execute('history')
end
--Show current work directory
function appleutil.CurrentDir( ... )
	return os.execute('pwd')
end
function appleutil.cwd( ... )
	return os.execute('pwd')
end

--Counting lines in archive
function appleutil.CountLines(archive)
	return os.execute('wc -l '..archive)
end
--Counting words in archive
function appleutil.CountWords(archive)
	return os.execute('wc -w '..archive)
end
--Counting characters in archive
function appleutil.CountChar(archive)
	return os.execute('wc '..archive)
end
--Counting characters in archive
function appleutil.CountCharacters(archive)
	return os.execute('wc '..archive)
end

--See the content inside a text archive
function appleutil.ShowSource(archive, ftype)
	if ftype == nil or 0 then
		return os.execute('cat '..archive)
	elseif ftype == "lines" or 1 then
		return os.execute('cat -n '..archive)
	else
		return print("Invalid code! Use 0 to simple opening or 1 to enumerate each line of the archive")
	end
end
--[[
CODES OF OPENING:
	CODE [nil, 0] - Only cat
	CODE ["lines", 1] - Cat with line numbers

USES OF ShowSource:
	appleutil.ShowSource("teste.txt", 0)
	appleutil.ShowSource("teste.txt", 1)
]]


--Rebooting Options
function appleutil.reboot( ... )
	return os.execute('sudo reboot')
end
function appleutil.specificReboot( ... )
	return os.execute('sudo reboot') --HERE
end

--Power off Options
function appleutil.shutdown( ... )
	return os.execute('sudo shutdown -h now')
end
--Power Off at specific time
function appleutil.specificMinuteShutdown(minuteTime)
	return os.execute('sudo shutdown -h +'..minuteTime)
end
function appleutil.specificShutdown(hourTime,minuteTime)
	return os.execute('sudo shutdown -h ' ..hourTime ..':' ..minuteTime)
end
--Open external application, archive or website on the Internet
function appleutil.openApplication(appName)
	return os.execute('open -a '..appName)
end
function appleutil.openArchive(archName)
	return os.execute('open '..archName)
end
--[[Examples of use:
	appleutil.openApplication("Safari")
	appleutil.openArchive("myfile.txt")
	
	SPECIFIC SHUTDOWN:
	appleutil.specificShutdown(10,30)
]]

return appleutil
