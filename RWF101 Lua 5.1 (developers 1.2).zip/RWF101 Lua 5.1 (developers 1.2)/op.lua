local op = {}
--LUA and Python Script Unified Language
--Operacoes matematicas basicas
function op.plus(num1,num2)
	return num1+num2
end
function op.minus(num1,num2)
	return num1-num2
end
function op.times(num1,num2)
	return num1*num2
end
function op.divided(num1,num2)
	return num1/num2
end

--Comparacao de valores
function op.different(num1,num2)
	return num1 ~= num2
end
function op.equal(num1,num2)
	return num1==num2
end

--Concatenacao de strings
function op.concat(string1, string2)
	return string1..string2
end

--Comparando maior e maior ou igual
function op.greater(num1, num2)
	return num1>num2
end
function op.greaterOrEqual(num1,num2)
	return num1>=num2
end

--Comparando menor e menor ou igual
function op.less(num1,num2)
	return num1<num2
end
function op.lessOrEqual(num1,num2)
	return num1<=num2
end
return op
