import redwhisky.util as util
import redwhisky.op as op
import redwhisky.advmath as advmath

try:
	#YOUR CODE GOES HERE
	util.wrf("Hello World!")
	util.scanner("string")
	
except:
	#WHEN AN ERROR OCCURS DURING PROJECT RUNTIME
	util.wrf("The program cannot be executed")
