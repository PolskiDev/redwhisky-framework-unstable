#LUA and Python Script Unified Language

#Show a text-mode Calendar
def showCalendar():
	return os.system('cal')

#Show a history of users log in
def showUsersLogin():
	return os.system('last')

#Show free space available on Hard Disk
def showFreeSpace():
	return os.system('df')

#Change the password of the current user on macOS
def changeUserPassword():
	print("===============================================================================")
	print("You are going to change the default password of the current local user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("===============================================================================")

	return os.system('passwd')

#Enable default user as root
def enableRootUser():
	print("======================================================================")
	print("You are going to enable the root user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("======================================================================")

	return os.system('dsenableroot')
#Clear terminal screen
def clear():
	return os.system('clear')