#LUA and Python Script Unified Language
def plus(num1,num2):
	return num1+num2
def minus(num1,num2):
	return num1-num2

def times(num1,num2):
	return num1*num2

def divided(num1,num2):
	return num1/num2

#comparacao de valores
def different(num1, num2):
	return num1!=num2
def equal(num1,num2):
	return num1==num2
	
#operadores avancados
def concat(string1, string2):
	return string1+string2

#maior e maior ou igual
def greater(num1, num2):
	return num1>num2
def greaterOrEqual(num1,num2):
	return num1>=num2

#menor e menor ou igual
def less(num1,num2):
	return num1<num2
def lessOrEqual(num1,num2):
	return num1<=num2