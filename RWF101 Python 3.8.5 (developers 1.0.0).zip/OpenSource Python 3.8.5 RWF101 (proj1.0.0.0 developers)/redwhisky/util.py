#LUA and Python Script Unified Language
def scanner(args):
	if args == "string":
		return str(input())
	if args == "int":
		return int(input())
	if args == "float":
		return float(input())
def wrf(msg):
	return print(msg)
