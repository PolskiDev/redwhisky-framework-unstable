import os
#Commands of the operating system
def runtime(com):
	return os.system(com) #Executing external programmes and isolated commands

#Deleting files
def delete(path, opsys):
	if opsys == "win" or 0:
		return runtime('rmdir /S /Q '+path) #For MS Windows
	elif opsys == "macos" or 1:
		return print("Use system.appleremove() to access this feature")
	else:
		return print('Invalid code on function delete!') #Invalid code error
#Renaming files
def rename(old_path, new_path,opsys):
	if opsys == "win" or 0:
		return runtime('ren '+old_path+' '+new_path) #For MS Windows
	elif opsys == "macos" or 1:
		return os.system('mv '+old_path+' '+new_path)
	else:
		return print('Invalid code on function delete!') #Invalid code error

#Getting Operating System current date
def getDate():
	return str(datetime.datetime.today()).split()[0]