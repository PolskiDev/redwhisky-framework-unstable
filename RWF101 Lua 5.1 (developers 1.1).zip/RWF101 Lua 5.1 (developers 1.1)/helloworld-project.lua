local Console = require("Console")
local appleutil = require("appleutil")

--WRITE DOWN YOUR CODE HERE
util.wrf("Hello World") --It writes "Hello World" message in the screen
util.scanner("string")

--[[USE OF APPLE UTIL TO SHOW THE CALENDAR
	util.wrf(appleutil.showCalendar())
]]