local appleutil = {}
--LUA and Python Script Unified Language

--Show a text-mode Calendar
function appleutil.showCalendar()
	return os.execute('cal')
end
--Show a history of users log in
function appleutil.showUsersLogin()
	return os.execute('last')
end
--Show free space available on Hard Disk
function appleutil.showFreeSpace()
	return os.execute('df')
end
--Change the password of the current user on macOS
function appleutil.changeUserPassword()
	print("===============================================================================")
	print("You are going to change the default password of the current local user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("===============================================================================")

	return os.execute('passwd')
end

--[[
	ROOT USER SECTION
]]
--Enable default user as root
function appleutil.enableRootUser()
	print("======================================================================")
	print("You are going to enable the root user account")
	print("If you do not agree with it, you should stop this program right now!")
	print("======================================================================")

	return os.execute('dsenableroot')
end
--Disable default user as root
function appleutil.disableRootUser( ... )
	return os.execute('dsenableroot -d')
end

--Enable defined user as root
function appleutil.enableDefinedRootUser(user)
	print("======================================================================")
	print("You are going to enable <"..user.."> as root user")
	print("If you do not agree with it, you should stop this")
	print("program right now!")
	print("======================================================================")

	return os.execute('dsenableroot -u '..user)
end
--Disable defined user as root
function appleutil.disableDefinedRootUser(user)
	return os.execute('dsenableroot -d -u '..user)
end
--Clear terminal screen
function appleutil.clear()
	return os.execute('clear')
end

return appleutil
