import math
import cmath
import random
from random import uniform

def sqroot(num):
	return math.sqrt(num)

def random(min, max, numtype):
	#NUMTYPE = "int" [random.randint(min,max)]
	#NUMTYPE = "float" [uniform(min,max)]
	if numtype == "int":
		return random.randint(min,max) #ERRO PARA SER CORRIGIDO AQUI
	elif numtype == "float":
		return uniform(min,max) #ERRO PARA SER CORRIGIDO AQUI
def mathpi():
	return math.pi

#Absolute value
def absnum(num):
	return abs(num)