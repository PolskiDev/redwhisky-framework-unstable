import util as util
import op as op
import advmath as advmath
import appleutil as appleutil

try:
	#YOUR CODE GOES HERE
	util.wrf("Hello World!")
	
except:
	#WHEN AN ERROR OCCURS DURING PROJECT RUNTIME
	util.wrf("The program cannot be executed")
