import string
#modulo de manipulacao de strings (stringx.lua)

#Saber a quantidade de caracteres numa string
def length(unique_string):
	len(unique_string)

#Mexendo com maiusculas e minusculas
def putLowerCase(unique_string):
	unique_string.lower()
def putUpperCase(unique_string):
	unique_string.upper()

#Colocando os caracteres na ordem reversa
def putReverseOrder(unique_string):
	unique_string[::-1] # method2

#Colocando todas as iniciais das palavras em maiusculas
def putEachUpperCase(unique_string):
	unique_string.title()

#O que estiver maiusculo vira minusculo e vice-versa
def ChangeEachCase(unique_string):
	unique_string.swapcase()