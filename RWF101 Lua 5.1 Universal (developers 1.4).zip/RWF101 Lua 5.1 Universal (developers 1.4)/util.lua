local util = {}
--LUA and Python Script Unified Language
function util.scanner(parser)
	if parser == nil then
		return io.read() --No arguments
	else
		return io.read() --Arguments [string, int, float]
	end
end
function util.wrf(msg)
	return print(msg)
end
function util.wrfln(msg)
	return print(msg.."\n")
end
return util
