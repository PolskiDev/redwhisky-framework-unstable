require('string')
local stringx = {}

--modulo de manipulacao de strings (stringx.lua)
function stringx.length(unique_string)
	return string.len(unique_string)
end

--Mexendo com maiusculas, minusculas e ordem das letras
function stringx.putLowerCase(unique_string)
	return string.lower(unique_string)
end
function stringx.putUpperCase(unique_string)
	return string.upper(unique_string)
end

function stringx.putReverseOrder(unique_string)
	return string.reverse(unique_string)
end
return stringx