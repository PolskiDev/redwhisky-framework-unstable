local Console = require("Console")

--WRITE DOWN YOUR CODE HERE
util.wrf("Hello World") --It writes "Hello World" message in the screen
util.scanner("string")
