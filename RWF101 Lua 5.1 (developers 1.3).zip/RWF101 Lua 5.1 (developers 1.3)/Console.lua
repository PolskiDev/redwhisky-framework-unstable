local Console = {}
--LUA and Python Script Unified Language
util = require('util') --Entrada e saida de dados
op = require('op') --Modulo de operacoes matematicas simples
advmath = require('advmath') --Modulo de operacoes matematicas complexas
stringx = require('stringx') --Modulo de manipulacao de strings
system = require('system') --Modulo de comandos do sistema operacional

appleutil = require('appleutil') --Modulo de comandos do Apple MacOS
return Console
