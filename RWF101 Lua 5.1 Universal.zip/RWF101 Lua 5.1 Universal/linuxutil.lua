local linuxutil = {}

--Show content inside a text archive
function linuxutil.ShowSource(archive, ftype)
	if ftype == nil or 0 then
		return os.execute('cat '..archive)
	elseif ftype == "lines" or 1 then
		return os.execute('cat -n '..archive)
	else
		return print("Invalid code! Use 0 to simple opening or 1 to enumerate each line of the archive")
	end
end
--Reboot Ubuntu
function linuxutil.reboot( ... )
	return os.execute('reboot')
end
--Power Off Ubuntu
function linuxutil.shutdown( ... )
	return os.execute('shutdown now')
end

--Show free space inside RAM memory
function linuxutil.freeMemory( ... )
	return os.execute('free -h')
end
--Show free space inside Hard Disk
function linuxutil.freeSpace( ... )
	return os.execute('df')
end

--Operations with directories
function linuxutil.newDirectory(dirname)
	return os.execute('mkdir '..dirname)
end
function linuxutil.removeDirectory(dirname)
	return os.execute('rmdir '..dirname)
end

--Show users login history
function linuxutil.showUsersLogin( ... )
	return os.execute('last')
end
--Show shell owner
function linuxutil.showShellOwner( ... )
	return os.execute('whoami')
end

return linuxutil