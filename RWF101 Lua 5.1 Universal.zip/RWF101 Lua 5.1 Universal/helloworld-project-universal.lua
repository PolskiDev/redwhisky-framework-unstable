local Console = require("Console")

--WRITE DOWN YOUR CODE HERE
util.wrfln("Hello World") --It writes "Hello World" message in the screen
util.scanner("string")
