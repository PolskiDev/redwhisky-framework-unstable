import os
#Show content inside a text archive
def ShowSource(archive, ftype):
	if ftype == None or 0:
		return os.system('cat '+archive)
	elif ftype == "lines" or 1:
		return os.system('cat -n '+archive)
	else:
		print("Invalid code! Use 0 to simple opening or 1 to enumerate each line of the archive")
	

#Reboot Ubuntu
def reboot():
	return os.system('reboot')

#Power Off Ubuntu
def shutdown():
	return os.system('shutdown now')


#Show free space inside RAM memory
def freeMemory():
	return os.system('free -h')

#Show free space inside Hard Disk
def freeSpace():
	return os.system('df')


#Operations with directories
def newDirectory(dirname):
	return os.system('mkdir '+dirname)

def removeDirectory(dirname):
	return os.system('rmdir '+dirname)
#CD and CD..
def goto(locdir):
	return os.system('cd '+locdir)
def gofwd():
	return os.system('cd ..')

#Show users login history
def showUsersLogin():
	return os.system('last')

#Show shell owner
def showShellOwner():
	return os.system('whoami')
