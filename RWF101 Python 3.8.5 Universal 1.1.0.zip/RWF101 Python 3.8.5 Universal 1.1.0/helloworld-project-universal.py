import util as util
import op as op
import advmath as advmath

try:
	#YOUR CODE GOES HERE
	util.wrfln("Hello World!")
	util.scanner("string") #If you are using Apple MacOS remove this line.
	
except:
	#WHEN AN ERROR OCCURS DURING PROJECT RUNTIME
	util.wrf("The program cannot be executed")
